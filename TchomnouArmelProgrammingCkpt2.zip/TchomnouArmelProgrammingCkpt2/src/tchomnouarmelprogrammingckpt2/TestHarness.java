/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tchomnouarmelprogrammingckpt2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author armel
 */
public class TestHarness {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //Book Title Array
        ArrayList<String> bTitle = new ArrayList<String>();
        bTitle.add("The Giver");
        bTitle.add("Can't Hurt Me");
        bTitle.add("To Kill a Mockingbird");
        bTitle.add("Maze Runner");
        bTitle.add("The Hunger Games");
        bTitle.add("Divergent");
        bTitle.add("Percy Jackson & The Lightning Thief");
        bTitle.add("The Sea of Monsters");
        bTitle.add("Harry Potter and the Sorcerer's Stone");
        bTitle.add("Harry Potter and the Chamber of Secrets");

        //Book Author Array
        ArrayList<String> author = new ArrayList<String>();
        author.add("Lois Lowry");
        author.add("David Goggins");
        author.add("Harper Lee");
        author.add("James Dashner");
        author.add("Suzanne Collins");
        author.add("Veronica Roth");
        author.add("Rick Riordan");
        author.add("Rick Riordan");
        author.add("J.K. Rowling");
        author.add("J.K. Rowling");

        //Book Price Array
        ArrayList<Double> bPrice = new ArrayList<Double>();
        bPrice.add(15.99);
        bPrice.add(17.99);
        bPrice.add(12.99);
        bPrice.add(17.99);
        bPrice.add(18.99);
        bPrice.add(18.99);
        bPrice.add(20.99);
        bPrice.add(19.99);
        bPrice.add(24.99);
        bPrice.add(24.99);
        
        //CD Title Array
        ArrayList<String> cTitle = new ArrayList<String>();
        cTitle.add("Freak No More");
        cTitle.add("Club Can't Handle Me");
        cTitle.add("Throw It In The Bag");
        cTitle.add("Whatta Man");
        cTitle.add("I Don't Mind");
        cTitle.add("Not Afraid");
        cTitle.add("Buy U a Drank");
        
        //CD Artist Array
        ArrayList<String> artist = new ArrayList<String>();
        artist.add("Migos");
        artist.add("Flo Rida ft. David Guetta");
        artist.add("Fabolous ft. The-Dream");
        artist.add("Salt-N-Pepa ft. En Vogue");
        artist.add("User ft. Juicy J");
        artist.add("Eminem");
        artist.add("T-Pain");
        
        //CD Genre Array
        ArrayList<String> cGenre = new ArrayList<String>();
        cGenre.add("Rap");
        cGenre.add("Pop");
        cGenre.add("R&B");
        cGenre.add("Pop");
        cGenre.add("Pop");
        cGenre.add("Rap");
        cGenre.add("R&B");
        
        
        //CD Price Array
        ArrayList<Double> cPrice = new ArrayList<Double>();
        cPrice.add(9.99);
        cPrice.add(7.99);
        cPrice.add(8.99);
        cPrice.add(7.99);
        cPrice.add(8.99);
        cPrice.add(9.99);
        cPrice.add(7.99);
        
        //DVD Title Array
        ArrayList<String> dTitle = new ArrayList<String>();
        dTitle.add("Spider-Man Far From Home");
        dTitle.add("Avengers Endgame");
        dTitle.add("Justice League");
        dTitle.add("Aquaman");
        dTitle.add("It Chapter Two");
        dTitle.add("Joker");
        dTitle.add("The Wolf of Wall Street");
        dTitle.add("Madagascar");
        dTitle.add("Jurassic World");
        
        //DVD Company Array
        ArrayList<String> company = new ArrayList<String>();
        company.add("Marvel");
        company.add("Marvel");
        company.add("DC");
        company.add("DC");
        company.add("New Line Cinema & Vertigo Entertainment");
        company.add("Warner bros. Pictures");
        company.add("Paramount Pictures");
        company.add("DreamWorks Pictures");
        company.add("Universal Pictures");
        
        //DVD Genre Array
        ArrayList<String> dGenre = new ArrayList<String>();
        dGenre.add("Action & Adventure");
        dGenre.add("Action & Adventure");
        dGenre.add("Action & Adventure");
        dGenre.add("Action & Adventure");
        dGenre.add("Horror");
        dGenre.add("Drama & Thriller");
        dGenre.add("Comedy, Drama, & Crime Fiction");
        dGenre.add("Comedy, Children's Film, Adventure");
        dGenre.add("Science Fiction, Action & Adventure, & Thriller");
        
        //DVD Price Array
        ArrayList<Double> dPrice = new ArrayList<Double>();
        dPrice.add(25.99);
        dPrice.add(29.99);
        dPrice.add(24.99);
        dPrice.add(26.99);
        dPrice.add(21.99);
        dPrice.add(27.99);
        dPrice.add(26.99);
        dPrice.add(18.99);
        dPrice.add(26.99);
        
        // variables for stuff
        String fName;
        String lName;
        String fName2;
        String lName2;
        
        // Scanner
        Scanner scan = new Scanner(System.in);
        
                
                
        // variables for loops
        int loop = 1;
        int loop2 = 1;
        
        //variables for totals
        double totB = 0.0;
        double totC = 0.0;
        double totD = 0.0;
        
        while (loop != 0) {

            System.out.println("Welcome to Mel's Bookstore!");
            System.out.println("\tIf you're a regular member, please enter '1' ");
            System.out.println("\tIf you're a premium member, please check your membership status "
                    + "and continue to the shop by entering '2' ");
            System.out.println("To exit the store, please enter '3'");
            loop2 = 1;

            

                int menu = scan.nextInt();

                switch (menu) {
                    case 1:
                        System.out.println("Please enter your first and last name: ");
                        fName = scan.nextLine();
                        lName = scan.nextLine();

                        Member member = new Member(fName, lName);
                        member.display();
                        break;

                    case 2:
                        System.out.println("Please enter your first and last name: ");
                        fName2 = scan.nextLine();
                        lName2 = scan.nextLine();

                        Premium member2 = new Premium(fName2, lName2, 20.0, "Credit Card", true);
                        member2.display();
                        break;
                    case 3:
                        System.out.println("Goodbye! Hope to see you again!");
                        loop = 0;
                        loop2 = 0;
                        break;
                    default: 
                        System.out.println("ERROR! Please enter a number from 1-3");

                }
                
                while (loop2 != 0) {
                
                System.out.println("\n What would you like to purchase?");
                System.out.println("\tTo purchase from the book section, "
                        + "enter '1'");
                System.out.println("\tTo purchase from the cd section, "
                        + "enter '2'");
                System.out.println("\tTo purchase from the dvd section, "
                        + "enter '3'");
                System.out.println("\tTo check your cart total, enter 4");
                System.out.println("\tTo exit the store, enter 5");
                
                int menu2 = scan.nextInt();
                
                
                switch (menu2) {
                    case 1:
                        System.out.println("Please choose a book from 1-10");
                        int book = scan.nextInt() - 1;
                        Book book1 = new Book(bTitle.get(book), bPrice.get(book), author.get(book));
                        book1.display();
                        System.out.println("How many of this book would you like?");
                        int numBook = scan.nextInt();
                        double total = numBook * bPrice.get(book);
                        System.out.println("This book purchase will cost you: $" + total);
                        //numB = numBook;
                        //valB = bPrice.get(book);
                        totB = total;
                        break;
                    case 2:
                        System.out.println("Please choose a CD from 1-7");
                        int cd = scan.nextInt() - 1;
                        CD cd1 = new CD(cTitle.get(cd), cPrice.get(cd), artist.get(cd), cGenre.get(cd));
                        cd1.display();
                        System.out.println("How many of this CD would you like?");
                        int numCD = scan.nextInt();
                        double cTotal = numCD * cPrice.get(cd);
                        System.out.println("This CD purchase will cost you $" + cTotal);
                        totC = cTotal;
                        break;
                    case 3:
                        System.out.println("Please choose a DVD from 1-9");
                        int dvd = scan.nextInt() - 1;
                        DVD dvd1 = new DVD(dTitle.get(dvd), dPrice.get(dvd), company.get(dvd), dGenre.get(dvd));
                        dvd1.display();
                        System.out.println("How many of this DVD would you like?");
                        int numDVD = scan.nextInt();
                        double dTotal = numDVD * dPrice.get(dvd);
                        System.out.println("This DVD purchase will cost you $" + dTotal);
                        totD = dTotal;
                        break;
                    case 4:
                        double finalTot = totB + totC + totD;
                        System.out.println("Your cart total is: $" + finalTot);
                        break;
                    case 5:
                        System.out.println("Goodbye! Hope to see you again!");
                        loop2 = 0;
                        totB = 0.0;
                        totC = 0.0;
                        totD = 0.0;
                        break;
                    default:
                        System.out.println("ERROR! Please enter a number from 1-5");
                }
            }

        }

    }

}
